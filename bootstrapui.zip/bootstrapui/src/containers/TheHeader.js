import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import {
  CHeader,
  CToggler,
  CHeaderBrand,
  CHeaderNav,
  CHeaderNavItem,
  CHeaderNavLink,
  CSubheader,
  CBreadcrumbRouter,
  CLink
} from '@coreui/react'
import CIcon from '@coreui/icons-react'

// routes config
import routes from '../routes'

import { 
  TheHeaderDropdown,
  TheHeaderDropdownMssg,
  TheHeaderDropdownNotif,
  TheHeaderDropdownTasks
}  from './index'

const TheHeader = () => {
  const dispatch = useDispatch()
  const sidebarShow = useSelector(state => state.sidebarShow)

  const toggleSidebar = () => {
    const val = [true, 'responsive'].includes(sidebarShow) ? false : 'responsive'
    dispatch({type: 'set', sidebarShow: val})
  }

  const toggleSidebarMobile = () => {
    const val = [false, 'responsive'].includes(sidebarShow) ? true : 'responsive'
    dispatch({type: 'set', sidebarShow: val})
  }

  return (
    <CHeader withSubheader>
      <CToggler
        inHeader
        className="ml-md-3 d-lg-none"
        onClick={toggleSidebarMobile}
      />
      <CToggler
        inHeader
        className="ml-3 d-md-down-none"
        onClick={toggleSidebar}
      />
      <CHeaderBrand className="mx-auto d-lg-none" to="/">
        <CIcon name="logo" height="48" alt="Logo"/>
      </CHeaderBrand>

      <CHeaderNav className="d-md-down-none mr-auto">
        <CHeaderNavItem className="px-4" >
          <CHeaderNavLink to="/dashboard">Company</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem  className="px-4">
          <CHeaderNavLink to="/users">FOSA Activities</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>Members</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>Maintenance</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>Loan Mgmt</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>parameters</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>Processes</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>Salary and Deductions</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>Accounts</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>Dividends</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>Security</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-4">
          <CHeaderNavLink>Reports</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-3">
          <CHeaderNavLink>Add-ins</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-3">
        <TheHeaderDropdownNotif/>
        </CHeaderNavItem>
      </CHeaderNav>

 
      <CSubheader className="px-3 justify-content-between">
        <CBreadcrumbRouter 
          className="border-0 c-subheader-nav m-0 px-0 px-md-3" 
          routes={routes} 
        />
             <CHeaderNav className="px-3">
        <TheHeaderDropdownNotif/>
        <TheHeaderDropdownTasks/>
        <TheHeaderDropdownMssg/>
        <TheHeaderDropdown/>
        <TheHeaderDropdownNotif/>
        <TheHeaderDropdownTasks/>
        <TheHeaderDropdownMssg/>
        <TheHeaderDropdown/>
        <TheHeaderDropdownNotif/>
        <TheHeaderDropdownTasks/>
        <TheHeaderDropdownMssg/>
        <TheHeaderDropdown/>
        <TheHeaderDropdownNotif/>
        <TheHeaderDropdownTasks/>
        <TheHeaderDropdownMssg/>
        <TheHeaderDropdown/>
        <TheHeaderDropdownNotif/>
        <TheHeaderDropdownTasks/>
        <TheHeaderDropdownMssg/>
        <TheHeaderDropdown/>
      </CHeaderNav>
      

          <div className="d-md-down-none mfe-2 c-subheader-nav">
            <CLink className="c-subheader-nav-link"href="#">
              <CIcon name="cil-speech" alt="Settings" />
            </CLink>
            <CLink 
              className="c-subheader-nav-link" 
              aria-current="page" 
              to="/dashboard"
            >
              <CIcon name="cil-graph" alt="Dashboard" />&nbsp;Dashboard
            </CLink>
            <CLink className="c-subheader-nav-link" href="#">
              <CIcon name="cil-settings" alt="Settings" />&nbsp;Settings
            </CLink>
            
          </div>
      </CSubheader>
    </CHeader>
  )
}

export default TheHeader
