import { Children } from "react";

export default [
  {
    _tag: 'CSidebarNavItem',
    name: 'Dashboard',
    to: '/dashboard',
    icon: 'cil-speedometer',
    badge: {
      color: 'info',
      text: 'NEW',
    }
  },
 
  {
    _tag: 'CSidebarNavTitle',
    _children: ['Components']
  },
  {
    _tag: 'CSidebarNavDropdown',
    name: 'Teller Activities',
    route: '/base',
    icon: 'cil-puzzle',
    _children: [
      {
        _tag: 'CSidebarNavItem',
        name: 'Cash Deposits',
        to: '/base/breadcrumbs',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Cash Withdraws',
        to: '/base/cards',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Loan,Int&shares (BOSA)Rcpt',
        to: '/base/carousels',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Cash Transfers',
        to: '/base/collapses',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Cheque Deposits',
        to: '/base/forms',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Bankers Cheques',
        to: '/base/jumbotrons',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Cheque Payment',
        to: '/base/list-groups',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Standing orders',
        to: '/base/navs',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Freign Cash Deposits',
        to: '/base/navbars',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Bank Receipts',
        to: '/base/paginations',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'ATM Reconciliation',
        to: '/base/popovers',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Loan Withdrawal',
        to: '/base/progress-bar',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Mpesa Transfers',
        to: '/base/switches',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'CRM Referals',
        to: '/base/tables',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Cheque Book Application',
        to: '/base/tabs',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Mobile Banking',
        to: '/base/tooltips',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Manual Cheque Books',
        to: '/base/tooltips',
      },
    ],
  },
  {
    _tag: 'CSidebarNavDropdown',
    name: 'Cross-Teller Transactions',
    route: '/buttons',
    icon: 'cil-cursor',
    _children: [
      {
        _tag: 'CSidebarNavItem',
        name: 'Borrow from Teller',
        to: '/buttons/buttons',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Lend to other Teller',
        to: '/buttons/brand-buttons',
      },
    
     
    ],
  },
  {
    _tag: 'CSidebarNavDropdown',
    name: 'Treasury Transactions',
    route: '/icons',
    icon: 'cil-star',
    _children: [
      {
        _tag: 'CSidebarNavItem',
        name: 'Receive from Treasury',
        to: '/icons/coreui-icons',
        badge: {
          color: 'success',
          text: 'NEW',
        },
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Return to Treasury',
        to: '/icons/flags',
      },
   
    ],
  },
  {
    _tag: 'CSidebarNavDropdown',
    name: 'Other Activities',
    route: '/notifications',
    icon: 'cil-bell',
    _children: [
      {
        _tag: 'CSidebarNavItem',
        name: 'Imprest Re-imbursement',
        to: '/notifications/alerts',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Company Bills',
        to: '/notifications/badges',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Import Data',
        to: '/notifications/modals',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Authorize Teller',
        to: '/notifications/toaster'
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'SASRA Reports',
        to: '/notifications/toaster'
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Liquidity Analyzer',
        to: '/notifications/toaster'
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'MBanking Settings',
        to: '/notifications/toaster'
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Final Accounts',
        to: '/notifications/toaster'
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'FOSA MFI Groups',
        to: '/notifications/toaster'
      },
    
    ]
  },

  {
    _tag: 'CSidebarNavDivider'
  },
  {
    _tag: 'CSidebarNavTitle',
    _children: ['Extras'],
  },
  {
    _tag: 'CSidebarNavDropdown',
    name: 'Debtors and Creditors',
    route: '/pages',
    icon: 'cil-star',
    _children: [
      {
        _tag: 'CSidebarNavItem',
        name: 'LPO and Deliveries',
        to: '/login',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Stock Requistion',
        to: '/register',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Dispatch Stock',
        to: '/404',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Receive Invoices',
        to: '/500',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Raise/Prepare Invoices ',
        to: '/500',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Supplier Management',
        to: '/500',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Consumer Management',
        to: '/500',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Debtor Invoices Paid',
        to: '/500',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Creditors Invoices',
        to: '/500',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Adjustments',
        to: '/500',
      },
    ],
  },
 
  {
    _tag: 'CSidebarNavDivider',
    className: 'm-2'
  },
  {
    _tag: 'CSidebarNavTitle',
    _children: ['Labels']
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Label danger',
    to: '',
    icon: {
      name: 'cil-star',
      className: 'text-danger'
    },
    label: true
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Label info',
    to: '',
    icon: {
      name: 'cil-star',
      className: 'text-info'
    },
    label: true
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Label warning',
    to: '',
    icon: {
      name: 'cil-star',
      className: 'text-warning'
    },
    label: true
  },
  {
    _tag: 'CSidebarNavDivider',
    className: 'm-2'
  }
]

